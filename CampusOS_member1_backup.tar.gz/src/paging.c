
#include <stdint.h>
#include "paging.h"

/* Page directory: 1024 entries, aligned to 4 KB */
static uint32_t page_directory[1024]
    __attribute__((aligned(4096)));

/* First page table: maps the first 4 MB */
static uint32_t first_page_table[1024]
    __attribute__((aligned(4096)));

void paging_init(void)
{
    /* Clear page directory */
    for (int i = 0; i < 1024; i++) {
        page_directory[i] = 0;
    }

    /* Identity-map the first 4 MB using 4 KB pages */
    for (int i = 0; i < 1024; i++) {
        first_page_table[i] =
            ((uint32_t)i * 4096) | 0x03;
    }

    /* Connect first page table to page directory */
    page_directory[0] =
        ((uint32_t)first_page_table) | 0x03;

    /* Load page directory address into CR3 */
    uint32_t pd_address = (uint32_t)page_directory;

    __asm__ volatile (
        "mov %0, %%cr3"
        :
        : "r"(pd_address)
        : "memory"
    );

    /* Enable paging using CR0 bit 31 */
    uint32_t cr0;

    __asm__ volatile (
        "mov %%cr0, %0"
        : "=r"(cr0)
    );

    cr0 |= 0x80000000;

    __asm__ volatile (
        "mov %0, %%cr0"
        :
        : "r"(cr0)
        : "memory"
    );
}
