
#ifndef INTERRUPTS_H
#define INTERRUPTS_H

#include <stdint.h>

struct interrupt_frame {
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
    uint32_t int_no, err_code;
    uint32_t eip, cs, eflags;
};

void idt_init(void);
void exception_handler(struct interrupt_frame *frame);

void pic_init(void);
void pit_init(uint32_t frequency);
void irq_handler(uint32_t vector);
uint32_t timer_get_ticks(void);

#endif
