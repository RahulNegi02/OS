
#include <stdint.h>
#include "interrupts.h"

static volatile uint16_t * const video =
    (volatile uint16_t *)0xB8000;

static void print_text(int row, int col, const char *text)
{
    int pos = row * 80 + col;

    for (int i = 0; text[i] != '\0' && col + i < 80; i++) {
        video[pos + i] =
            (uint16_t)text[i] | (0x0C << 8);
    }
}

static void print_hex(int row, int col, uint32_t value)
{
    const char digits[] = "0123456789ABCDEF";
    int pos = row * 80 + col;

    for (int i = 0; i < 8 && col + i < 80; i++) {
        unsigned shift = (unsigned)(7 - i) * 4;

        video[pos + i] =
            (uint16_t)digits[(value >> shift) & 0x0F]
            | (0x0C << 8);
    }
}

void exception_handler(struct interrupt_frame *frame)
{
    __asm__ volatile ("cli");

    print_text(0, 0, "CampusOS: CPU Exception");
    print_text(1, 0, "Exception Number:");
    print_hex(1, 18, frame->int_no);

    if (frame->int_no == 0) {
        print_text(2, 0, "Divide-by-zero error");
    }
    else if (frame->int_no == 6) {
        print_text(2, 0, "Invalid Opcode");
    }
    else if (frame->int_no == 13) {
        print_text(2, 0, "General Protection Fault");
    }
    else if (frame->int_no == 14) {
        print_text(2, 0, "Page Fault");
    }
    else {
        print_text(2, 0, "Unknown CPU Exception");
    }

    for (;;) {
        __asm__ volatile ("hlt");
    }
}
